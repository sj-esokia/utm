/**
 * @file
 * imdbthemetest2 behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.imdbthemetest2 = {
    attach (context, settings) {

      console.log('It works!');

    }
  };

} (Drupal));
